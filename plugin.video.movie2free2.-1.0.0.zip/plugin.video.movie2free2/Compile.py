# create a byte code compiled python file

import py_compile
py_compile.compile("addon.py")